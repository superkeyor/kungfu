from kungfu import *
from kungfu import __doc__
from version import __version__