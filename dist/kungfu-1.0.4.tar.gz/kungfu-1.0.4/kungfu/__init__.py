from kungfu import *
__doc__ = kungfu.__doc__
from packageversion import __version__